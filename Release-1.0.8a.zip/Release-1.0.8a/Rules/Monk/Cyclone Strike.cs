﻿using System.Linq;
using D3Macro.Models;
using Enigma.D3.MemoryModel;
using Enigma.D3.MemoryModel.Core;
using Enigma.D3.Enums;

namespace D3Macro.Rules
{
    public static class Cyclone_Strike
    {
        public static int Interval = 500; // suggested timer interval in milliseconds

        public static bool Skill(int sno, int runeIndex)
        {
            try
            {

                if (!Models.CurrentPlayer.IsPlayerValid
                    || Models.CurrentPlayer.LifePercentage == 0
                    || Helpers.Attributes.IsSkillOnCooldown(sno))
                    return false;

                if (CurrentPlayer.Spirit < 125) return false;

                return !Models.CurrentPlayer.IsMoving && Models.CurrentPlayer.IsInCombat;                
            }
            catch
            {
                return false;
            }
        } //
    }
}
