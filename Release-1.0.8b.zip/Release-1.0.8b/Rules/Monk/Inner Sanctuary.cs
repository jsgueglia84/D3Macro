﻿using D3Macro.Models;
using Enigma.D3.MemoryModel;
using Enigma.D3.MemoryModel.Core;
using Enigma.D3.Enums;

namespace D3Macro.Rules
{
    public static class Inner_Sanctuary
    {
        public static int Interval = 200; // suggested timer interval in milliseconds

        public static bool Skill(int sno, int runeIndex)
        {
            //if (!Models.CurrentPlayer.IsPlayerValid) return false;
            if (!Models.CurrentPlayer.IsInCombat) return false;
            
            var isBuffActive = D3Macro.Helpers.PlayerSkills.GetBuff(Models.CurrentPlayer.PlayerAcd, 317076, AttributeId.BuffIconCount1) == 1;

            if (CurrentPlayer.IsMoving) return false;

            return AttributeReader.Instance.GetAttributeValue(Models.CurrentPlayer.PlayerAcd.FastAttribGroupID, AttributeId.PowerCooldown,sno) == -1                    
                   && !isBuffActive
                   && CurrentPlayer.LifePercentage != 0;
        }
    }
}
