﻿using Enigma.D3.MemoryModel;
using Enigma.D3.MemoryModel.Core;
using Enigma.D3.Enums;

namespace D3Macro.Rules
{
    public static class AutoPotion
    {
        public static bool Skill(int sno, int runeIndex, int potionPercent)
        {
            try
            {
                if (0 == potionPercent) return false;
                if (!Models.CurrentPlayer.IsPlayerValid) return false;
                
                return AttributeReader.Instance.GetAttributeValue(Models.CurrentPlayer.PlayerAcd.FastAttribGroupID,
                           AttributeId.PowerCooldown, sno) == -1 
                       && Models.CurrentPlayer.LifePercentage < potionPercent 
                       && Models.CurrentPlayer.LifePercentage != 0;
            }
            catch { }
            return false;            
        } //
    }
}
