﻿using D3Macro.Models;
using Enigma.D3.MemoryModel;
using Enigma.D3.MemoryModel.Core;
using Enigma.D3.Enums;

namespace D3Macro.Rules
{
    public static partial class Akarats_Champion
    {
        public static int Interval = 200; // suggested timer interval in milliseconds
        public static bool Skill(int sno, int runeIndex)
        {                       
            try
            {                
                var bufClock = Helpers.PlayerSkills.GetBuff(Models.CurrentPlayer.PlayerAcd, sno, AttributeId.BuffIconEndTick1);
                var gameTick = Globals.GameTick;
                var buffExpired = gameTick + Interval >= bufClock || bufClock == 0;                
                if (!buffExpired) return false;
                var monstersNearMe = new Models.MonstersNearPlayer(50);
                if (AttributeReader.Instance.GetAttributeValue(CurrentPlayer.PlayerAcd.FastAttribGroupID, AttributeId.PowerCooldown, sno) == -1 && Models.CurrentPlayer.LifePercentage != 0 && monstersNearMe.Monsters.Count > 0) return true;

                return false;
            }
            catch { }
            return false;
        } //
    }
}