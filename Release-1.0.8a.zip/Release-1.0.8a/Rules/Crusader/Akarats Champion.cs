﻿using D3Macro.Models;
using Enigma.D3.MemoryModel;
using Enigma.D3.MemoryModel.Core;
using Enigma.D3.Enums;

namespace D3Macro.Rules
{
    public static partial class Akarats_Champion
    {
        public static int Interval = 200; // suggested timer interval in milliseconds
        public static bool Skill(int sno, int runeIndex)
        {                       
            try
            {                
                //if (!Models.CurrentPlayer.IsPlayerValid) return false;
                if (!Models.CurrentPlayer.IsInCombat) return false;

                //var bufClock = Helpers.PlayerSkills.GetBuff(Globals.GameInfo.Game.Player.ACD, sno, AttributeId.BuffIconEndTick1);
                //var gameTick = Globals.GameInfo.Game.Tick;
                //var buffExpired = gameTick + Interval >= bufClock || bufClock == 0;
                var monstersNearMe = new Models.MonstersNearPlayer(50);

                //if (!CurrentPlayer.IsMoving && !CurrentPlayer.IsInCombat && !buffExpired) return false;
                if (!CurrentPlayer.IsMoving && !CurrentPlayer.IsInCombat) return false;
                if (AttributeReader.Instance.GetAttributeValue(CurrentPlayer.PlayerAcd.FastAttribGroupID, AttributeId.PowerCooldown, sno) == -1 && Models.CurrentPlayer.LifePercentage != 0 && monstersNearMe.Monsters.Count > 0) return true;
                return false;
            }
            catch { }
            return false;
        } //
    }
}