﻿using System.Linq;
using D3Macro.Models;
using Enigma.D3.MemoryModel;
using Enigma.D3.MemoryModel.Core;
using Enigma.D3.Enums;

namespace D3Macro.Rules
{
    public static class Ignore_Pain
    {
        public static int Interval = 200; // suggested timer interval in milliseconds, populates user form
        public static bool Skill(int sno, int runeIndex) // <-- The skill function must be named Skill with a return type of bool
        {
            try
            {

                if (Models.CurrentPlayer.LifePercentage == 0
                     || Helpers.Attributes.IsSkillOnCooldown(sno))
                    return false;

                var monstersNearMe = new Models.MonstersNearPlayer(50);

                return Models.CurrentPlayer.IsInCombat
                       || monstersNearMe.ChampionCount > 1
                       || monstersNearMe.RareCount > 1
                       || monstersNearMe.BossCount > 1;
            }
            catch
            {
                return false;
            }
        }
    } // class
}