﻿using D3Macro.Models;
using Enigma.D3.MemoryModel;
using Enigma.D3.MemoryModel.Core;
using Enigma.D3.Enums;

namespace D3Macro.Rules
{
    public static class Mantra_of_Salvation
    {
        public static int Interval = 200; // suggested timer interval in milliseconds
        public static bool Skill(int sno, int runeIndex)
        {            
            if (Helpers.Attributes.IsSkillOnCooldown(sno)) return false;
            if (Models.CurrentPlayer.PrimaryResrouce <= 100) return false;
            if (CurrentPlayer.LifePercentage == 0) return false;

            var isSkillActive = Helpers.PlayerSkills.GetBuff(CurrentPlayer.PlayerAcd, 375050, AttributeId.BuffIconCount1) !=0;
            if (isSkillActive) return false;

            var monstersNearMe = new Models.MonstersNearPlayer(50);
            return monstersNearMe.Monsters.Count >= 1;
        }
    }
}
