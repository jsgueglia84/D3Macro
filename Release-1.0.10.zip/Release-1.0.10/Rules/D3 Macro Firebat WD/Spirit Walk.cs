﻿using Enigma.D3.MemoryModel;
using Enigma.D3.MemoryModel.Core;
using Enigma.D3.Enums;

namespace D3Macro.Rules
{
    public static class Spirit_Walk
    {
        public static int Interval = 200; // suggested timer interval in milliseconds
        public static bool Skill(int sno, int runeIndex)
        {
            try
            {
                
                
                var notOnCooldown = AttributeReader.Instance.GetAttributeValue(Models.CurrentPlayer.PlayerAcd.FastAttribGroupID,
                                       AttributeId.PowerCooldown, sno) == -1;
                
                return (notOnCooldown
                       && Models.CurrentPlayer.LifePercentage < 35
                       && Models.CurrentPlayer.LifePercentage != 0) || (notOnCooldown && Models.CurrentPlayer.Mana < 100);
            }
            catch { }
            return false;
        } //
    }
}
