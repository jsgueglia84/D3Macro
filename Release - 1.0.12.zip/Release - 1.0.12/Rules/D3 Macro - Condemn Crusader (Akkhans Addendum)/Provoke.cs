﻿using Enigma.D3.MemoryModel;
using Enigma.D3.MemoryModel.Core;
using Enigma.D3.Enums;

namespace D3Macro.Rules
{
    public static class Provoke
    {
        public static int Interval = 200; // suggested timer interval in milliseconds
        public static bool Skill(int sno, int runeIndex)
        {
            try
            {                
                //
                if (!Models.CurrentPlayer.IsInCombat) return false;
                
                var fury = D3Macro.Models.CurrentPlayer.PrimaryResource;
                
                return AttributeReader.Instance.GetAttributeValue(Models.CurrentPlayer.PlayerAcd.FastAttribGroupID, AttributeId.PowerCooldown, sno) == -1 && Models.CurrentPlayer.LifePercentage != 0 && fury < 90;
            }
            catch { }
            return false;
        } //
    }
}