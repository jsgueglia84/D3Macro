﻿using D3Macro.Models;
using Enigma.D3.MemoryModel;
using Enigma.D3.MemoryModel.Core;
using Enigma.D3.Enums;

namespace D3Macro.Rules
{
    public static class Epiphany
    {
        public static int Interval = 200; // suggested timer interval in milliseconds
        public static bool Skill(int sno, int runeIndex)
        {
            if (!Models.CurrentPlayer.IsPlayerValid) return false;
            var isBuffActive = D3Macro.Helpers.PlayerSkills.GetBuff(Models.CurrentPlayer.PlayerAcd, sno, AttributeId.BuffIconCount1) == 1;
            var monstersNearMe = new Models.MonstersNearPlayer(40);

            return Helpers.PlayerSkills.GetBuff(Models.CurrentPlayer.PlayerAcd, sno, AttributeId.BuffIconCount0) < 1 
                   && !isBuffActive
                   && AttributeReader.Instance.GetAttributeValue(Models.CurrentPlayer.PlayerAcd.FastAttribGroupID, AttributeId.PowerCooldown, sno) == -1
                   && Models.CurrentPlayer.LifePercentage != 0
                   && monstersNearMe.Monsters.Count > 0;
        }
    }
}
