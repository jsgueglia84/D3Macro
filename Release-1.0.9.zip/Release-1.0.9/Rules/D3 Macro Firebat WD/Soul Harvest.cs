﻿using D3Macro.Models;
using Enigma.D3.MemoryModel;
using Enigma.D3.MemoryModel.Core;
using Enigma.D3.Enums;

namespace D3Macro.Rules
{
   public static class Soul_Harvest
    {
        public static int Interval = 200; // suggested timer interval in milliseconds
        public static bool Skill(int sno, int runeIndex)
        {
            try
            {
                
                var stackCount = Helpers.PlayerSkills.GetBuff(CurrentPlayer.PlayerAcd,sno, AttributeId.BuffIconCount0);
                var buffActive = Helpers.PlayerSkills.GetBuff(CurrentPlayer.PlayerAcd, sno, AttributeId.PowerBuff0VisualEffectC) == 1;
                
                var monstersNearMe = new Models.MonstersNearPlayer(18);
                if ((monstersNearMe.Monsters.Count > 1 && buffActive)
                    || monstersNearMe.BossCount > 0
                    || monstersNearMe.RareCount > 0
                    || monstersNearMe.ChampionCount > 0
                    || monstersNearMe.UniqueCount > 0
                    || (stackCount < 1 && monstersNearMe.Monsters.Count > 3))
                {
                    return AttributeReader.Instance.GetAttributeValue(CurrentPlayer.PlayerAcd.FastAttribGroupID,
                               AttributeId.PowerCooldown, sno) == -1 && Models.CurrentPlayer.LifePercentage != 0;
                }                                
            }
            catch { }
            return false;
        } //
    }
}
