﻿using Enigma.D3.MemoryModel;
using Enigma.D3.MemoryModel.Core;
using Enigma.D3.Enums;

namespace D3Macro.Rules
{
    public static class Evasive_Fire
    {
        public static int Interval = 200; // suggested timer interval in milliseconds
        public static bool Skill(int sno, int runeIndex)
        {
            // RuneIndex 0 = Evasive Fire Hardened
            // RuneIndex 4 = Evasive Fire Focus
            try
            {                              
                if (!Models.CurrentPlayer.IsMoving && Models.CurrentPlayer.LifePercentage != 0)
                {
                    if (Models.CurrentPlayer.Hatred <= 50) return true;
                }

                switch (runeIndex)
                {
                    case 0:
                        if (Models.CurrentPlayer.IsInCombat && !Models.CurrentPlayer.IsMoving && Models.CurrentPlayer.LifePercentage != 0)
                        {                            
                            if (Models.CurrentPlayer.Hatred <= 50) return true;
                        }
                        break;

                    case 4:                            
                            if (Models.CurrentPlayer.Hatred <= 50 && !Models.CurrentPlayer.IsMoving && Models.CurrentPlayer.LifePercentage != 0) return true;
                        break;

                    default:
                        break;
                }

                
                return false;
            }
            catch { }
            return false;
        } //
    }
}
