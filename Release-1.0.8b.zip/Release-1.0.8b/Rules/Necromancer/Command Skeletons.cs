﻿using D3Macro.Models;
using Enigma.D3.MemoryModel;
using Enigma.D3.MemoryModel.Core;
using Enigma.D3.Enums;

namespace D3Macro.Rules
{
    public static class Command_Skeletons
    {
        public static int Interval = 200; // suggested timer interval in milliseconds
        public static bool Skill(int sno, int runeIndex)
        {
            try
            {
                if (!Models.CurrentPlayer.IsPlayerValid) return false;
                if (!Models.CurrentPlayer.IsInCombat) return false;

                var buffActive = Helpers.PlayerSkills.GetBuff(CurrentPlayer.PlayerAcd, sno, AttributeId.BuffIconCount5) == 1;

                return AttributeReader.Instance.GetAttributeValue(CurrentPlayer.PlayerAcd.FastAttribGroupID, AttributeId.PowerCooldown, sno) == -1
                       && !buffActive
                       && Models.CurrentPlayer.LifePercentage != 0;
            }
            catch { }
            return false;
        } //
    }
}
