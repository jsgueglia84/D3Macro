﻿using System.Linq;
using D3Macro.Models;
using Enigma.D3.MemoryModel;
using Enigma.D3.MemoryModel.Core;
using Enigma.D3.Enums;

namespace D3Macro.Rules
{
    public static class Whirlwind
    {
        public static int Interval = 200; // suggested timer interval in milliseconds, populates user form
        public static bool Skill(int sno, int runeIndex) // <-- The skill function must be named Skill with a return type of bool
        {
            throw new System.NotImplementedException("No rule created, please create one");
        }
    } // class
}