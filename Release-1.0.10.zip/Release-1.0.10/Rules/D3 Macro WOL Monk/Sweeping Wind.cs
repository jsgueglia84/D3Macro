﻿using System.Linq;
using D3Macro.Models;
using Enigma.D3.MemoryModel;
using Enigma.D3.MemoryModel.Core;
using Enigma.D3.Enums;

namespace D3Macro.Rules
{
    public static class Sweeping_Wind
    {
        public static int Interval = 200; // suggested timer interval in milliseconds, populates user form
        public static bool Skill(int sno, int runeIndex) // <-- The skill function must be named Skill with a return type of bool
        {
            if (Models.CurrentPlayer.Spirit <= 75) return false;
            if (CurrentPlayer.LifePercentage == 0) return false;

            var isSkillActive = Helpers.PlayerSkills.GetBuff(CurrentPlayer.PlayerAcd, sno, AttributeId.BuffIconCount0) != 0;
            if (!isSkillActive) return true;
            return false;
            
        }
    } // class
}