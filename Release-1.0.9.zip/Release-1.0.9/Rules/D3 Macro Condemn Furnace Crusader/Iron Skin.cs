﻿using System;
using Enigma.D3.Assets;
using Enigma.D3.MemoryModel;
using Enigma.D3.MemoryModel.Core;
using Enigma.D3.Enums;

namespace D3Macro.Rules
{
    public static class Iron_Skin
    {
        public static int Interval = 200; // suggested timer interval in milliseconds
        public static bool Skill(int sno, int runeIndex)
        {
            try
            {                
                //
                if (!Models.CurrentPlayer.IsInCombat) return false;
                //var lawOfHopeBufActive = D3Macro.Helpers.PlayerSkills.GetBuff(Models.CurrentPlayer.PlayerAcd, 342299, AttributeId.BuffIconCount4);
                var notOnCooldown = AttributeReader.Instance.GetAttributeValue(Models.CurrentPlayer.PlayerAcd.FastAttribGroupID, AttributeId.PowerCooldown,sno) == -1;

                //if (!D3Macro.Models.CurrentPlayer.IsMoving) return false;
                //if (lawOfHopeBufActive == 0 && notOnCooldown ) return true;  // If Laws of Valor movement buff dropped
                var lifePercent = Models.CurrentPlayer.LifePercentage;
                return notOnCooldown && Models.CurrentPlayer.LifePercentage != 0 && lifePercent <=60;
            }
            catch
            {
                return false;
            }
        } //
    } //class
}