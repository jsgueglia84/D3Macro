﻿using Enigma.D3.MemoryModel;
using Enigma.D3.MemoryModel.Core;
using Enigma.D3.Enums;
using System.Linq;
using System.Collections.Generic;

namespace D3Macro.Rules
{
    public static class Skeletal_Mage
    {
        public static int Interval = 200; // suggested timer interval in milliseconds

        public static bool Skill(int sno, int runeIndex)
        {           
            var mageCount = Helpers.PlayerSkills.PlayerPetCount("skeletonmage");
            var monsters = new Models.MonstersNearPlayer(50);
            if (monsters.Monsters.Count == 0) return false;

            // if Land of Dead active 
            if (Helpers.PlayerSkills.GetBuff(Models.CurrentPlayer.PlayerAcd, 465839, AttributeId.BuffIconCount0) > 0 &&
                Models.CurrentPlayer.Essence >= 100 && mageCount < 8 &&
                Models.CurrentPlayer.LifePercentage != 0) return true;

            var isInCombat = AttributeReader.Instance.GetAttributeValue(Models.CurrentPlayer.PlayerAcd.FastAttribGroupID,
                    AttributeId.InCombat);

            if (isInCombat == 0) return false;

            if (Models.CurrentPlayer.Essence >= 100 && mageCount < 4 &&
                Models.CurrentPlayer.LifePercentage != 0) return true;

            if (Models.CurrentPlayer.Essence >= 300 && mageCount < 8 &&
                Models.CurrentPlayer.LifePercentage != 0) return true;

            return false;
        }
    } //
}