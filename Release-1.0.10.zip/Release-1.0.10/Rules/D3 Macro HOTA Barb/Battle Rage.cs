﻿using Enigma.D3.MemoryModel;
using Enigma.D3.MemoryModel.Core;
using Enigma.D3.Enums;

namespace D3Macro.Rules
{
    public static class Battle_Rage
    {
        public static int Interval = 3000; // suggested timer interval in milliseconds
        public static bool Skill(int sno, int runeIndex)
        {            
            return Models.CurrentPlayer.LifePercentage != 0           
                   && Models.CurrentPlayer.Fury >= 20;
        }
    }
}
