﻿using Enigma.D3.MemoryModel;
using Enigma.D3.MemoryModel.Core;
using Enigma.D3.Enums;

namespace D3Macro.Rules
{
    public static class Preparation
    {
        public static int Interval = 200; // suggested timer interval in milliseconds
        public static bool Skill(int sno, int runeIndex)
        {
            try
            {                
                return AttributeReader.Instance.GetAttributeValue(Models.CurrentPlayer.PlayerAcd.FastAttribGroupID, AttributeId.PowerCooldown, sno) == -1 && Models.CurrentPlayer.Discipline <= 40 && Models.CurrentPlayer.LifePercentage != 0;
            }
            catch { }
            return false;
        } //
    }
}
