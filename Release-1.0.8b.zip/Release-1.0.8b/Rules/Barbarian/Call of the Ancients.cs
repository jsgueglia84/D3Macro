﻿using Enigma.D3.MemoryModel;
using Enigma.D3.MemoryModel.Core;
using Enigma.D3.Enums;
using System.Linq;
using System.Collections.Generic;

namespace D3Macro.Rules
{
    public static class Call_of_the_Ancients
    {
        public static int Interval = 200; // suggested timer interval in milliseconds
        public static bool Skill(int sno, int runeIndex)
        {
            if (!Models.CurrentPlayer.IsPlayerValid) return false;

            var ancientsCount = Helpers.PlayerSkills.PlayerPetCount("ancients");
              
            return (ancientsCount < 3 
                    && Models.CurrentPlayer.LifePercentage != 0 
                    && Helpers.PlayerSkills.IsSkillNotOnCoolDown(sno)) 
                    ? true : false;                                       
        } //
    }
}
